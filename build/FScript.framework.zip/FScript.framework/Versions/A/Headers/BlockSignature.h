/*   BlockSignature.h Copyright (c) 1998-2009 Philippe Mougin.  */
/*   This software is open source. See the license.  */  

struct BlockSignature 
{
  int argumentCount;
  BOOL hasLocals;
};

